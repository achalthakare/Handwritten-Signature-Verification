import React from 'react';
import { Link, Outlet } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import { FaHome, FaUser, FaUserPlus, FaGraduationCap, FaChalkboardTeacher, FaBuilding } from 'react-icons/fa';

function App() {
  return (
    <div style={{ fontFamily: 'Arial, sans-serif', minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      {/* Header Section */}
      <header className="bg-dark text-white text-center p-4 shadow">
        <h1 className="fw-bold">✍ Handwritten Signature Verification</h1>
        <nav className="mt-3">
          <div className="d-flex justify-content-center">
            <Link to="/" className="nav-link text-white px-3 fw-semibold">
              <FaHome className="me-1" /> Home
            </Link>
            <Link to="/login" className="nav-link text-white px-3 fw-semibold">
              <FaUser className="me-1" /> Login
            </Link>
            <Link to="/registration" className="nav-link text-white px-3 fw-semibold">
              <FaUserPlus className="me-1" /> Register
            </Link>
            <Link to="/student" className="nav-link text-white px-3 fw-semibold">
              <FaGraduationCap className="me-1" /> Student
            </Link>
            <Link to="/headofdepartment" className="nav-link text-white px-3 fw-semibold">
              <FaChalkboardTeacher className="me-1" /> Head of Department
            </Link>
            <Link to="/warden" className="nav-link text-white px-3 fw-semibold">
              <FaBuilding className="me-1" /> Warden
            </Link>
          </div>
        </nav>
      </header>

      {/* Main Content */}
      <main className="container flex-grow-1 py-4">
        <Outlet />
      </main>

      {/* Footer Section */}
      <footer className="bg-dark text-white text-center py-3 mt-auto">
        <p className="mb-0">
          &copy; {new Date().getFullYear()} Handwritten Signature Verification | Made By 3rd Year
        </p>
      </footer>
    </div>
  );
}

export default App;
