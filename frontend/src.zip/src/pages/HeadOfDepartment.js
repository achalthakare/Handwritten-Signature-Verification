import React from 'react';

function HeadOfDepartment() {
  return (
    <div style={{ 
      display: 'flex', 
      flexDirection: 'column', 
      alignItems: 'center', 
      padding: '20px', 
      backgroundColor: '#f0f0f0', 
      minHeight: '100vh',
      boxSizing: 'border-box' // Include padding in minHeight calculation
    }}>

   
    
      <div style={{ width: '80%', maxWidth: '800px' }}> {/* Adjust width as needed */}
        <div style={{ backgroundColor: '#e6f4ea', padding: '20px', marginBottom: '20px', borderRadius: '8px' }}>
          <h2 style={{ marginBottom: '10px', color: '#0f9d58' }}>Leave Approved</h2>
          <p style={{ marginBottom: '15px' }}>
            The student John Doe has been approved for leave from March 10, 2025 to March 15, 2025.
          </p>
          <button style={{ backgroundColor: '#0f9d58', color: 'white', padding: '10px 20px', border: 'none', borderRadius: '5px', cursor: 'pointer' }}>
            Acknowledge
          </button>
        </div>

        <div style={{ backgroundColor: '#fce8e6', padding: '20px', borderRadius: '8px' }}>
          <h2 style={{ marginBottom: '10px', color: '#db4437' }}>Fake Signature Detected</h2>
          <p style={{ marginBottom: '15px' }}>
            The student John Doe has submitted a leave application with a suspected fake signature. Please verify and take necessary actions.
          </p>
          <button style={{ backgroundColor: '#db4437', color: 'white', padding: '10px 20px', border: 'none', borderRadius: '5px', cursor: 'pointer' }}>
            Take Action
          </button>
        </div>
      </div>
    </div>
  );
}


export default HeadOfDepartment;