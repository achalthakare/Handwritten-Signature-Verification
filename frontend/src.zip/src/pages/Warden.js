import React from 'react';

function Warden() {
  return (
    <div style={{ 
      display: 'flex', 
      justifyContent: 'center', 
      alignItems: 'center', 
      minHeight: '100vh', 
      backgroundColor: '#f0f0f0' 
    }}>
        
      <div style={{ 
        backgroundColor: 'white', 
        padding: '30px', 
        borderRadius: '10px', 
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)', 
        width: '400px', 
        textAlign: 'center' 
      }}>
        <h1 style={{ marginBottom: '30px' }}>Verify Leave Request</h1>

        <div style={{ textAlign: 'left', marginBottom: '20px' }}>
          <label style={{ display: 'block', marginBottom: '10px' }}>Upload Signature Image:</label>
          <div style={{ display: 'flex', alignItems: 'center' }}>
            <button style={{ padding: '8px 12px', border: '1px solid #ccc', borderRadius: '4px', marginRight: '10px' }}>
              Choose File
            </button>
            <span>No file chosen</span>
          </div>
        </div>

        <button style={{ 
          backgroundColor: '#673ab7', 
          color: 'white', 
          padding: '12px 20px', 
          border: 'none', 
          borderRadius: '5px', 
          marginBottom: '30px', 
          width: '100%' 
        }}>
          Upload & Verify
        </button>

        <h2 style={{ marginBottom: '20px', textAlign: 'left' }}>Decision</h2>

        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <button style={{ 
            backgroundColor: '#4caf50', 
            color: 'white', 
            padding: '12px 20px', 
            border: 'none', 
            borderRadius: '5px', 
            width: '48%' 
          }}>
            Approve Leave
          </button>
          <button style={{ 
            backgroundColor: '#f44336', 
            color: 'white', 
            padding: '12px 20px', 
            border: 'none', 
            borderRadius: '5px', 
            width: '48%' 
          }}>
            Deny Leave
          </button>
        </div>
      </div>
    </div>
  );
}


export default Warden;