import React from 'react';

function RegistrationPage() {
  return (
    <div
      style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: '100vh',
       // background: 'linear-gradient(to right, #6a11cb, #2575fc)', // Gradient background
      }}
    >
      <div
        style={{
          backgroundColor: 'white',
          padding: '30px',
          borderRadius: '10px',
          boxShadow: '0 8px 16px rgba(0, 0, 0, 0.1)', // Box shadow for modern look
          width: '320px', // Reduced width to make form smaller
          textAlign: 'center',
        }}
      >
        <h2
          style={{
            color: '#222',
            marginBottom: '20px',
            fontFamily: 'Arial, sans-serif',
            fontWeight: 'bold',
            fontSize: '22px',
            textTransform: 'uppercase',
            marginTop: '10px', // Added margin to ensure visibility
          }}
        >
          Register
        </h2>

        {/* Name Input */}
        <div style={{ marginBottom: '15px', textAlign: 'left' }}>
          <label style={{ fontSize: '14px', fontWeight: 'bold', color: '#333' }}>* Name:</label>
          <input
            type="text"
            placeholder="Enter your name"
            style={inputStyle}
          />
        </div>

        {/* Mobile No Input */}
        <div style={{ marginBottom: '15px', textAlign: 'left' }}>
          <label style={{ fontSize: '14px', fontWeight: 'bold', color: '#333' }}>* Mobile No:</label>
          <input
            type="tel"
            placeholder="Enter your mobile number"
            style={inputStyle}
          />
        </div>

        {/* Department (Optional) */}
        <div style={{ marginBottom: '15px', textAlign: 'left' }}>
          <label style={{ fontSize: '14px', fontWeight: 'bold', color: '#333' }}>Department (Optional):</label>
          <input
            type="text"
            placeholder="Enter your department"
            style={inputStyle}
          />
        </div>

        {/* Year (Optional) */}
        <div style={{ marginBottom: '15px', textAlign: 'left' }}>
          <label style={{ fontSize: '14px', fontWeight: 'bold', color: '#333' }}>Year (Optional):</label>
          <input
            type="text"
            placeholder="Enter your year"
            style={inputStyle}
          />
        </div>

        {/* Password Input */}
        <div style={{ marginBottom: '15px', textAlign: 'left' }}>
          <label style={{ fontSize: '14px', fontWeight: 'bold', color: '#333' }}>* Password:</label>
          <input
            type="password"
            placeholder="Enter your password"
            style={inputStyle}
          />
        </div>

        {/* Category Dropdown */}
        <div style={{ marginBottom: '20px', textAlign: 'left' }}>
          <label style={{ fontSize: '14px', fontWeight: 'bold', color: '#333' }}>* Category:</label>
          <select style={inputStyle}>
            <option value="student">Student</option>
            <option value="warden">Warden</option>
            <option value="hod">HOD</option>
          </select>
        </div>

        {/* Register Button */}
        <button
          style={{
            backgroundColor: '#28a745', // Green button
            color: 'white',
            padding: '12px',
            border: 'none',
            borderRadius: '6px',
            fontSize: '16px',
            cursor: 'pointer',
            width: '100%',
            transition: 'background-color 0.3s ease',
          }}
          onMouseEnter={(e) => e.target.style.backgroundColor = '#218838'}
          onMouseLeave={(e) => e.target.style.backgroundColor = '#28a745'}
        >
          Register
        </button>

        {/* Login Link */}
        <div style={{ marginTop: '15px', fontSize: '13px' }}>
          <p style={{ color: '#666' }}>
            Already have an account? <a href="#" style={{ color: '#4285f4', textDecoration: 'none' }}>Login</a>
          </p>
        </div>
      </div>
    </div>
  );
}

// Common input field styling
const inputStyle = {
  width: '100%',
  padding: '10px',
  borderRadius: '6px',
  border: '1px solid #ccc',
  fontSize: '14px',
  boxSizing: 'border-box',
  outline: 'none',
  transition: 'border-color 0.3s ease',
};

export default RegistrationPage;

