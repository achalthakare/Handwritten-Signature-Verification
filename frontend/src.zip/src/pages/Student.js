import React from 'react';

function Student() {
  return (
    <div style={{ 
      display: 'flex', 
      justifyContent: 'center', 
      alignItems: 'center', 
      minHeight: '100vh', // Use minHeight to allow content to expand
      backgroundColor: '#f0f0f0' 
    }}>
        
      <div style={{ 
        backgroundColor: 'white', 
        padding: '30px', 
        borderRadius: '10px', 
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)', 
        width: '400px', // Adjust width as needed
        textAlign: 'center' 
      }}>
        {/* <h1 style={{ marginBottom: '20px', fontSize: '24px' }}>Student Dashboard</h1> */}
        <h2 style={{ marginBottom: '25px', fontSize: '20px' }}>Notifications</h2>

        <div style={{ 
          backgroundColor: '#f9f9f9', 
          padding: '20px', 
          borderRadius: '8px', 
          textAlign: 'left' 
        }}>
          <p style={{ marginBottom: '5px', fontWeight: 'bold' }}>New: Your leave request has been approved.</p>
          <p style={{ fontSize: '14px', color: '#666' }}>March 10, 2025</p>
        </div>
      </div>
    </div>
  );
}

export default Student;