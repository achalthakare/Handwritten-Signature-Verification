package com.example.demo.auth.services;

import com.example.demo.auth.models.LeaveRequest;
import com.example.demo.auth.repository.LeaveRequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class LeaveRequestService {

    @Autowired
    private LeaveRequestRepository leaveRequestRepository;

    // Save or update leave request
    public LeaveRequest saveLeaveRequest(String studentEmail, String status) {
        Optional<LeaveRequest> existingRequest = leaveRequestRepository.findByStudentEmail(studentEmail);

        LeaveRequest leaveRequest;
        if (existingRequest.isPresent()) {
            leaveRequest = existingRequest.get();
            leaveRequest.setStatus(status); // Update existing request status
        } else {
            leaveRequest = new LeaveRequest(studentEmail, status); // Create new request
        }

        return leaveRequestRepository.save(leaveRequest);
    }

    // Get leave request by student email
    public Optional<LeaveRequest> getLeaveRequest(String studentEmail) {
        return leaveRequestRepository.findByStudentEmail(studentEmail);
    }
}
