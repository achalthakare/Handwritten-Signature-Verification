package com.example.demo.auth.controllers;

import com.example.demo.auth.models.LeaveRequest;
import com.example.demo.auth.services.LeaveRequestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;
@CrossOrigin(origins = "http://localhost:3000")  // Allow frontend requests
@RestController
@RequestMapping("/api/leave")
public class LeaveRequestController {

    @Autowired
    private LeaveRequestService leaveRequestService;

    @PostMapping("/decision")
    public LeaveRequest updateLeaveStatus(@RequestParam String studentEmail, @RequestParam String status) {
        return leaveRequestService.saveLeaveRequest(studentEmail, status);
    }

    @GetMapping("/status")
    public Optional<LeaveRequest> getLeaveStatus(@RequestParam String studentEmail) {
        return leaveRequestService.getLeaveRequest(studentEmail);
    }

    // 🔹 Handle preflight requests explicitly
    @RequestMapping(value = "/decision", method = RequestMethod.OPTIONS)
    public void handlePreflight() {
        // No implementation needed, just an empty response to let the browser proceed
    }
}
